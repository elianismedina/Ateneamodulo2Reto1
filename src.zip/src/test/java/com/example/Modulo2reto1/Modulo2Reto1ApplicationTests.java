package com.example.Modulo2reto1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Modulo2Reto1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
