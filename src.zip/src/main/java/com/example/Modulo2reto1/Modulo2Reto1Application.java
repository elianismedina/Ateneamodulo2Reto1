package com.example.Modulo2reto1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modulo2Reto1Application {

	public static void main(String[] args) {
		SpringApplication.run(Modulo2Reto1Application.class, args);
	}

}
